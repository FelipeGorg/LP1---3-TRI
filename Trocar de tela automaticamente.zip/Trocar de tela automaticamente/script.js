/*1-Importar os id's que vamos usar */
const botaoClicavel = document.getElementById("botao-trocador")
const corEscolhda = document.getElementById("cor-escolhida")
const backgroundEscolhido = document.body
/*2-fazer o array com as opções de cores*/

const CoresPossiveis = ["#012E40", "#024959", "#026773", "#3CA6A6", "#F2E3D5"]


botaoClicavel.addEventListener('click', function () {
    CoresAleatorias = CoresPossiveis[Math.floor(Math.random() * CoresPossiveis.length)]
    backgroundEscolhido.style.backgroundColor = CoresAleatorias
    corEscolhda.innerText = CoresAleatorias

    if (CoresAleatorias === "#024959" || CoresAleatorias === "#012E40") {
        corEscolhda.style.color = "#fff"
    }
    else {
        corEscolhda.style.color = "#000"
    }
});
/*Qunaod apertar o botão ele sorteará uma cor diferente */

/*sortear uma cor diferente */