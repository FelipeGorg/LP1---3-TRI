// function adicionar(){

//     const personagens = ['Steven', 'Ametista', 'Pérola', 'Peridote']
//     const novoPersonagem = document.getElementById('input-usuario')
    
//     //Coloca um elemento no FINAL
//     personagens.push('Cleonice')

//     //Coloca um elemento no INICIO
//     personagens.unshift('Cleo')

//     //Exlcui o ultimo
//     personagens.pop()
//     //Atualizar um valor
//     personagens[2] = 'Garnet'

//     //Como pegar cada valor do array
//     personagens.forEach(function(PegaPersonagem){
//         console.log
//     })
// }

//FUNÇÃO PARA MULTIPLICAR  CADA NUMERO DO ARRAY---------------------------------------v
//                                                                                    |                                                                                      |   
// const escolhaUsuario = parseInt(prompt('Digite um numero para ser multiplicado'))  | 
// const escolhaUsuario = parseInt(prompt('Digite um numero para ser multiplicado'))  | 
// const numeros = [2,4,6,8]                                                          |  
//                                                                                    |        
// numeros.forEach( function(numeros){                                                |          
//     resultado = numeros * escolhaUsuario;                                          |      
//     parseInt(resultado)                                                            |  
//     console.log(`${numeros} * ${escolhaUsuario} = ${resultado}`)                   |                  
// })---------------------------------------------------------------------------------|


let produtos = []
const formulario = document.getElementById('formProdutos')
const inputProduto = document.getElementById('produto')
const listaSupermercado = document.getElementById('listaSupermercado')

function fazerLista(){
    listaSupermercado.innerHTML = ""
    //Com a array criada agora é adicionar os elemetnos dentro dela

    produtos.forEach((produto, index) => {
        //Criar a estrutura da lista
        const li = document.createElement('li')
        const span = document.createElement('span')

        span.textContent = produto;

        //Criar botão de edição, fazendo a estrutura por variaveis
        const containerBotoes = document.createElement('div')
        const botaoEditar = document.createElement('button')
        btnEditar.style.backgroundColor = '#16a085';
        btnEditar.textContent = 'Editar';
        //Chamar a função ao clicar no botão
        botaoEditar.onclick = ()=> editarproduto(index);

        //Criar o botão de remoção
        const btnRemover = document.createElement('button');
        btnRemover.style.backgroundColor = '#e74c3c';
        btnRemover.textContent = 'Remover';
        btnRemover.onclick = () => removerProduto(index)

                //o appendChild é usado para acresentar a estrutura normalmente da ul

        li.appendChild(span)
        li.appendChild(containerBotoes)
        containerBotoes.appendChild(btnEditar)
        containerBotoes.appendChild(btnRemover);
        listaSupermercado.appendChild(li);
        
    });

}


//Adicionar Produto
formulario.addEventListener('submit', (e) => {
    e.preventDefault();
    const produto = inputProduto.ariaValueMax.trim();
     if(produto != ''){
        produtos.push(produto);
        inputProduto.value = '';
        renderizarLista()
     }
})

//função para remover produto
function removerProduto(index){
    produtos.splice(index, 1);
    renderizarLista();
}

//Função para editar produto
function editarproduto(index){
    const novoProduto = prompt("Editar Produto", produtos[index]);
    if(novoProduto != null && novoProduto.trim() !== ''){
        produtos[index] = novoProduto.trim()
        renderizarLista()
    }
}
